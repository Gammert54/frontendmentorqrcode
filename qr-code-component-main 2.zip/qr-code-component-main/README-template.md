# Frontend Mentor - QR code component solution

This is a solution to the [QR code component challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/qr-code-component-iux_sIO_H). Frontend Mentor challenges help you improve your coding skills by building realistic projects.

## Table of contents

- [Overview](#overview)
  - [Screenshot](#screenshot)
  - [Links](#links)
- [My process](#my-process)
  - [Built with](#built-with)
  - [What I learned](#what-i-learned)
  - [Useful resources](#useful-resources)
- [Author](#author)
- [Acknowledgments](#acknowledgments)

**Note: Delete this note and update the table of contents based on what sections you keep.**

## Overview

### Screenshot

![](./screenshot.png)

### Links

- Solution URL: [Add solution URL here](https://your-solution-url.com)
- Live Site URL: [Add live site URL here](https://your-live-site-url.com)

## My process

### Built with

- HTML5 Markup
- CSS custom properties
- Flexbox

**Note: These are just examples. Delete this note and replace the list above with your own choices**

### What I learned

I have learned a lot of things about how to make a responsible design without having to use the `@media` attribute. Here are some code snippets from this project!

```html
<div id="container">
  <img src="images/image-qr-code.png" alt="QRCODE" draggable="false" />
  <h2>Improve your front-end skills by building projects</h2>
  <span>
    Scan the QR code to visit Frontend Mentor and take your coding skills to the
    next level</span
  >
</div>
```

```css
#container {
  display: flex;
  flex-direction: column;
  max-width: 18rem;
  height: auto;
  background: #fff;
  padding: 1.2rem;
  border-radius: 0.5rem;
  -webkit-box-shadow: 0px 0px 55px -16px rgba(0, 0, 0, 1);
  -moz-box-shadow: 0px 0px 55px -16px rgba(0, 0, 0, 1);
  box-shadow: 0px 0px 55px -16px rgba(0, 0, 0, 1);
  text-align: center;
  padding-bottom: 2.3rem;
  font-family: 'Outfit', sans-serif;
}
```

### Useful resources

- [Frontend Mentor](https://www.frontendmentor.io) - This helped me because, I have started making projects outside of my comfort zone.

## Author

- Website - [@Foxxo](https://amsterdamportfolio.adambuksowicz.repl.co)

## Acknowledgments

I would like to acknowledge Frontend Mentor as it helped me with a lot of development! Thanks!
